import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Filter, Check, Search } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';

interface CategoriesPageProps {
  initialCategory: string;
  onProductClick: (p: Product) => void;
  onBack: () => void;
  key?: React.Key;
}

const CategoriesPage = ({ initialCategory, onProductClick, onBack }: CategoriesPageProps) => {
  const [activeCategory, setActiveCategory] = useState(initialCategory === 'All' ? 'All' : initialCategory);
  const [maxPrice, setMaxPrice] = useState(100);
  const [isFilterOpen, setIsFilterOpen] = useState(true);

  const allProducts: Product[] = [
    { id: 'p-1', name: "Legendary Whitetails Women's Outfitter Hoodie", price: 32.00, img: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=400&auto=format&fit=crop', category: 'Women' },
    { id: 'p-2', name: 'Autumn Harajuku Print Hoodies Women Sailor', price: 40.00, img: 'https://images.unsplash.com/photo-1578939608332-5842854df112?q=80&w=400&auto=format&fit=crop', category: 'Women' },
    { id: 'p-3', name: "Long Gnome Hooded Top Women's Sleeve", price: 39.00, img: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=400&auto=format&fit=crop', category: 'Women' },
    { id: 'p-4', name: "Men's Favorite for Winter Collection", price: 55.00, img: 'https://images.unsplash.com/photo-1520975916090-310595b439bf?q=80&w=400&auto=format&fit=crop', category: 'Men' },
    { id: 'p-5', name: 'Arctix Boys Ronan Insulated Winter Jacket', price: 29.00, img: 'https://images.unsplash.com/photo-1545594944-42b8744424dc?q=80&w=400&auto=format&fit=crop', category: 'Children' },
    { id: 'p-6', name: "Carhartt Women's Loose Fit T-Shirt", price: 24.00, oldPrice: 30.00, img: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=400&auto=format&fit=crop', category: 'Women' },
    { id: 'p-7', name: "Lee Men's Extreme Motion Cargo", price: 45.00, img: 'https://images.unsplash.com/photo-1565084888279-aff996979482?q=80&w=400&auto=format&fit=crop', category: 'Men' },
    { id: 'p-8', name: 'Winter Knitted Beanie Hat', price: 15.00, img: 'https://images.unsplash.com/photo-1521369909029-2afed882baee?q=80&w=400&auto=format&fit=crop', category: 'Winter' },
    { id: 'p-9', name: 'Heavy Duty Winter Parka', price: 89.00, img: 'https://images.unsplash.com/photo-1539533113208-f6df8cc8b543?q=80&w=400&auto=format&fit=crop', category: 'Winter' },
    { id: 'p-10', name: 'Classic Wool Scarf', price: 19.00, img: 'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?q=80&w=400&auto=format&fit=crop', category: 'Winter' },
  ];

  const filteredProducts = useMemo(() => {
    return allProducts.filter(p => {
      const catMatch = activeCategory === 'All' || p.category === activeCategory;
      const priceMatch = p.price <= maxPrice;
      return catMatch && priceMatch;
    });
  }, [activeCategory, maxPrice]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="bg-white min-h-screen pb-20"
    >
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-full transition-all group">
              <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
            </button>
            <h1 className="text-3xl font-bold tracking-tight">Explore {activeCategory} Collections</h1>
          </div>
          <button 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all border ${isFilterOpen ? 'bg-brand-blue text-white border-brand-blue' : 'bg-white text-gray-600 border-gray-100 hover:border-gray-300'}`}
          >
            <Filter size={16} />
            Filters
          </button>
        </div>

        <div className="grid lg:grid-cols-4 gap-12">
          {/* Filters Sidebar */}
          <AnimatePresence>
            {isFilterOpen && (
              <motion.div 
                initial={{ opacity: 0, x: -20, width: 0 }}
                animate={{ opacity: 1, x: 0, width: 'auto' }}
                exit={{ opacity: 0, x: -20, width: 0 }}
                className="lg:col-span-1 space-y-10 pr-6 border-r border-gray-50 overflow-hidden"
              >
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">Categories</h3>
                  <div className="flex flex-col gap-2">
                    {['All', 'Men', 'Women', 'Children', 'Winter'].map((cat) => (
                      <button 
                        key={cat} 
                        onClick={() => setActiveCategory(cat)}
                        className={`flex items-center justify-between px-4 py-3 rounded-2xl text-sm font-bold transition-all group ${activeCategory === cat ? 'bg-brand-blue text-white' : 'text-gray-500 hover:bg-gray-50'}`}
                      >
                        {cat}
                        {activeCategory === cat && <Check size={16} />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">Price Range</h3>
                    <span className="text-xs font-bold text-brand-blue">${maxPrice}</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="100" 
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(parseInt(e.target.value))}
                    className="w-full h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-brand-blue"
                  />
                  <div className="flex justify-between text-[10px] text-gray-400 font-bold">
                    <span>$0</span>
                    <span>$100+</span>
                  </div>
                </div>

                <div className="pt-6 border-t border-gray-100">
                  <button 
                    onClick={() => { setActiveCategory('All'); setMaxPrice(100); }}
                    className="w-full py-4 text-xs font-bold text-gray-400 hover:text-brand-blue transition-colors text-center uppercase tracking-widest"
                  >
                    Reset All Filters
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Product Grid */}
          <div className={`${isFilterOpen ? 'lg:col-span-3' : 'lg:col-span-4'}`}>
            <AnimatePresence mode="popLayout">
              {filteredProducts.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="py-24 text-center bg-gray-50 rounded-[3rem]"
                >
                  <Search size={40} className="mx-auto text-gray-200 mb-6" />
                  <h3 className="text-xl font-bold mb-2">No items found</h3>
                  <p className="text-sm text-gray-400">Try adjusting your filters to find what you're looking for.</p>
                </motion.div>
              ) : (
                <motion.div 
                  layout
                  className="grid sm:grid-cols-2 xl:grid-cols-3 gap-8"
                >
                  {filteredProducts.map((p) => (
                    <ProductCard key={p.id} product={p} onProductClick={onProductClick} />
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default CategoriesPage;
