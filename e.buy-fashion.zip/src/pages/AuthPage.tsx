import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, ShieldCheck, Sparkles, User, Mail, Lock, EyeOff, Eye, Check, ArrowRight } from 'lucide-react';
import { User as UserType } from '../types';

interface AuthPageProps {
  onAuthSuccess: (u: UserType) => void;
  onBack: () => void;
  key?: React.Key;
}

const AuthPage = ({ onAuthSuccess, onBack }: AuthPageProps) => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [stayLoggedIn, setStayLoggedIn] = useState(false);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    const user: UserType = {
      id: 'u-1',
      name: isLogin ? 'John Doe' : name,
      email: email,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=100&auto=format&fit=crop',
      joinedAt: 'Jan 2024'
    };
    onAuthSuccess(user);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen bg-white flex flex-col md:flex-row relative z-[60]"
    >
      {/* Back Button */}
      <button 
        onClick={onBack}
        className="absolute top-8 left-8 z-[70] p-3 bg-white/10 hover:bg-white text-white hover:text-brand-dark rounded-2xl transition-all border border-white/20 shadow-xl backdrop-blur-lg"
      >
        <ArrowLeft size={20} />
      </button>

      {/* Left Branding Column */}
      <div className="hidden md:flex md:w-5/12 lg:w-1/2 bg-gradient-to-br from-[#0B2149] via-[#103067] to-[#01112D] text-white p-20 flex-col justify-between relative overflow-hidden">
        {/* Decorative Watermark */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-[0.03] font-black text-[25rem] pointer-events-none select-none tracking-tighter">
          EBUY
        </div>

        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/10 rounded-full border border-white/20 mb-12 backdrop-blur-md">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-bold uppercase tracking-widest">The Flagship Experience</span>
          </div>
          
          <h1 className="text-8xl font-black tracking-tighter leading-[0.85] mb-8">
            E.buy<br />
            <span className="text-blue-400/90 italic">Ecosystem.</span>
          </h1>
          
          <p className="text-xl text-gray-300 max-w-lg leading-relaxed font-light">
            Where high-performance shopping meets editorial elegance. Access your curated digital catalog today.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-6 relative z-10">
          <div className="bg-white/10 backdrop-blur-sm border border-white/10 p-8 rounded-[2rem] hover:bg-white/15 transition-colors group cursor-default">
            <div className="w-12 h-12 bg-blue-500 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-500/20">
              <ShieldCheck size={24} className="text-white" />
            </div>
            <h3 className="text-lg font-bold mb-1">Secure Sync</h3>
            <p className="text-sm text-gray-400">Military-grade protection</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm border border-white/10 p-8 rounded-[2rem] hover:bg-white/15 transition-colors group cursor-default">
            <div className="w-12 h-12 bg-blue-400 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-400/20">
              <Sparkles size={24} className="text-white" />
            </div>
            <h3 className="text-lg font-bold mb-1">Curated Picks</h3>
            <p className="text-sm text-gray-400">Tailored to your taste</p>
          </div>
        </div>
      </div>

      {/* Right Form Column */}
      <div className="flex-1 flex flex-col justify-center items-center px-8 sm:px-12 py-24 bg-white">
        <div className="w-full max-w-md">
          <div className="mb-12">
            <h2 className="text-4xl font-bold tracking-tight mb-3 text-brand-dark">
              {isLogin ? 'Welcome Back' : 'Get Started'}
            </h2>
            <p className="text-gray-400 font-medium">Enter your credentials to access your account.</p>
          </div>

          {/* Login/Register Tabs */}
          <div className="bg-gray-100 p-1.5 rounded-3xl mb-10 flex border border-gray-100/50 shadow-inner">
            <button 
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3.5 rounded-2xl text-sm font-bold transition-all ${isLogin ? 'bg-white text-brand-blue shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
            >
              Login
            </button>
            <button 
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3.5 rounded-2xl text-sm font-bold transition-all ${!isLogin ? 'bg-white text-brand-blue shadow-sm' : 'text-gray-500 hover:text-gray-900'}`}
            >
              Register
            </button>
          </div>

          <button className="w-full bg-white border-2 border-gray-100 hover:border-brand-blue/30 py-4 px-6 rounded-2xl flex items-center justify-center gap-4 transition-all group mb-10">
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
            </svg>
            <span className="text-sm font-bold text-gray-700">Continue with Google</span>
          </button>

          <div className="relative mb-10 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100"></div>
            </div>
            <span className="relative px-6 bg-white text-[10px] font-black uppercase tracking-[0.2em] text-gray-300">Or Email</span>
          </div>

          <form onSubmit={handleAuth} className="space-y-6">
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 pl-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                  <input 
                    type="text" 
                    placeholder="Alex Smith"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full bg-gray-50/80 border border-gray-100 rounded-2xl px-14 py-4 focus:outline-none focus:border-brand-blue focus:bg-white transition-all font-medium text-sm text-brand-dark"
                  />
                </div>
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 pl-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input 
                  type="email" 
                  placeholder="alex@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full bg-gray-50/80 border border-gray-100 rounded-2xl px-14 py-4 focus:outline-none focus:border-brand-blue focus:bg-white transition-all font-medium text-sm text-brand-dark"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between pl-1 pr-1">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Password</label>
                <button type="button" className="text-[10px] font-bold text-brand-blue hover:underline">Forgot password?</button>
              </div>
              <div className="relative">
                <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
                <input 
                  type={showPassword ? 'text' : 'password'} 
                  placeholder="••••••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full bg-gray-50/80 border border-gray-100 rounded-2xl px-14 py-4 focus:outline-none focus:border-brand-blue focus:bg-white transition-all font-medium text-sm text-brand-dark tracking-widest"
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-6 top-1/2 -translate-y-1/2 text-gray-300 hover:text-brand-blue transition-colors px-1"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button 
                type="button"
                onClick={() => setStayLoggedIn(!stayLoggedIn)}
                className={`w-5 h-5 rounded-md border-2 transition-all flex items-center justify-center ${stayLoggedIn ? 'bg-brand-blue border-brand-blue' : 'border-gray-200 bg-white'}`}
              >
                {stayLoggedIn && <Check size={12} className="text-white" />}
              </button>
              <span className="text-xs font-semibold text-gray-500 select-none cursor-pointer" onClick={() => setStayLoggedIn(!stayLoggedIn)}>
                Keep me logged in for 30 days
              </span>
            </div>

            <button 
              type="submit"
              className="w-full bg-brand-blue hover:bg-blue-600 text-white font-bold py-5 rounded-[1.25rem] transition-all shadow-xl shadow-blue-100 flex items-center justify-center gap-3 group"
            >
              <span>{isLogin ? 'Sign In' : 'Create Account'}</span>
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          <div className="mt-12 text-center">
            <p className="text-sm font-semibold text-gray-500">
              {isLogin ? "Don't have an account?" : "Already have an account?"}{' '}
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-brand-blue hover:underline ml-1"
              >
                {isLogin ? 'Create an account' : 'Sign In instead'}
              </button>
            </p>
          </div>

          <div className="mt-24 text-center">
            <p className="text-[10px] font-bold text-gray-300 uppercase tracking-[0.25em]">
              © 2024 NEXASTORE TECHNOLOGY GROUP • PRIVACY • TERMS
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default AuthPage;
