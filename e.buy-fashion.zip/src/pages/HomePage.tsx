import React from 'react';
import { motion } from 'motion/react';
import Hero from '../components/home/Hero';
import Categories from '../components/home/Categories';
import BestSellers from '../components/home/BestSellers';
import NewCollections from '../components/home/NewCollections';
import SeasonalPicks from '../components/home/SeasonalPicks';
import BestOffers from '../components/home/BestOffers';
import WhyChooseUs from '../components/home/WhyChooseUs';
import Testimonials from '../components/home/Testimonials';
import InstagramGrid from '../components/home/InstagramGrid';
import { Product } from '../types';

interface HomePageProps {
  onProductClick: (p: Product) => void;
  onCategoryClick: (c: string) => void;
  key?: React.Key;
}

const HomePage = ({ onProductClick, onCategoryClick }: HomePageProps) => {
  return (
    <motion.div 
      key="home"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <Hero />
      <div id="home-categories-nav">
        <Categories onCategoryClick={onCategoryClick} />
      </div>
      <BestSellers onProductClick={onProductClick} />
      <NewCollections />
      <SeasonalPicks onProductClick={onProductClick} />
      <BestOffers onProductClick={onProductClick} />
      <WhyChooseUs />
      <Testimonials />
      <InstagramGrid />
    </motion.div>
  );
};

export default HomePage;
