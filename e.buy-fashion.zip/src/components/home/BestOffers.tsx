import React from 'react';
import SectionHeader from '../common/SectionHeader';
import ProductCard from '../ProductCard';
import { Product } from '../../types';

interface BestOffersProps {
  onProductClick: (p: Product) => void;
}

const BestOffers = ({ onProductClick }: BestOffersProps) => {
  const products: Product[] = [
    { id: 'offer-1', name: 'Gildan Adult Fleece Zip...', price: 18.00, oldPrice: 24.00, rating: 4.5, img: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=400&auto=format&fit=crop', category: 'Men' },
    { id: 'offer-2', name: 'Lee Men\'s Extreme Motion...', price: 20.00, oldPrice: 20.00, rating: 5, img: 'https://images.unsplash.com/photo-1565084888279-aff996979482?q=80&w=400&auto=format&fit=crop', category: 'Men' },
    { id: 'offer-3', name: 'Amazon Essentials Men\'s...', price: 16.00, oldPrice: 20.00, rating: 4, img: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=400&auto=format&fit=crop', discount: 20, category: 'Men' },
    { id: 'offer-4', name: 'Carhartt Women\'s Loose...', price: 24.00, oldPrice: 30.00, rating: 4.5, img: 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?q=80&w=400&auto=format&fit=crop', category: 'Women' },
  ];

  return (
    <section className="px-6 py-16">
      <div className="max-w-7xl mx-auto">
        <SectionHeader title="Today's best offers" showButton />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} onProductClick={onProductClick} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default BestOffers;
