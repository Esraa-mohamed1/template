import React from 'react';
import { motion } from 'motion/react';

interface CategoriesProps {
  onCategoryClick: (c: string) => void;
}

const Categories = ({ onCategoryClick }: CategoriesProps) => {
  const categories = [
    { id: 'cat-men', name: 'Men', img: 'https://picsum.photos/seed/men-f/200/200' },
    { id: 'cat-women', name: 'Women', img: 'https://picsum.photos/seed/women-f/200/200' },
    { id: 'cat-children', name: 'Children', img: 'https://picsum.photos/seed/child-f/200/200' },
    { id: 'cat-aged', name: 'Aged', img: 'https://picsum.photos/seed/aged-f/200/200' },
    { id: 'cat-summer', name: 'Summer', img: 'https://picsum.photos/seed/summer-f/200/200' },
    { id: 'cat-winter', name: 'Winter', img: 'https://picsum.photos/seed/winter-f/200/200' },
  ];

  return (
    <section id="categories-section" className="px-6 py-16 bg-white">
      <div className="max-w-7xl mx-auto">
        <h2 id="categories-title" className="text-3xl font-bold text-center mb-12">Popular categories</h2>
        <div id="categories-grid" className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {categories.map((cat) => (
            <motion.div 
              id={cat.id}
              key={cat.id}
              whileHover={{ y: -5 }}
              onClick={() => onCategoryClick(cat.name)}
              className="group cursor-pointer flex flex-col items-center"
            >
              <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-2 border-gray-100 group-hover:border-brand-blue transition-colors">
                <img src={cat.img} alt={cat.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <span className="font-semibold text-gray-700">{cat.name}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
