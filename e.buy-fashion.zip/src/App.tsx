import React, { useState } from 'react';
import { AnimatePresence } from 'motion/react';

// Layout & Navigation
import Navbar from './components/layout/Navbar';
import BottomNavbar from './components/layout/BottomNavbar';
import Footer from './components/layout/Footer';

// Pages
import HomePage from './pages/HomePage';
import ProductPage from './pages/ProductPage';
import CartPage from './pages/CartPage';
import CategoriesPage from './pages/CategoriesPage';
import AuthPage from './pages/AuthPage';
import ProfilePage from './pages/ProfilePage';
import CheckoutPage from './pages/CheckoutPage';

// Types & Services
import { User, Order, Transaction, Product, CartItem } from './types';
import * as orderService from './services/orderService';

export default function App() {
  const [view, setView] = useState<'home' | 'product' | 'cart' | 'categories' | 'checkout' | 'auth' | 'profile'>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState('All');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setView('product');
  };

  const handleLogoClick = () => {
    setView('home');
    setSelectedProduct(null);
  };

  const handleCategoryClick = (cat: string) => {
    setActiveCategory(cat);
    setView('categories');
  };

  const handleAddToCart = (product: Product, quantity: number = 1, size?: string, color?: string) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id && item.selectedSize === size && item.selectedColor === color);
      if (existing) {
        return prev.map(item => 
          (item.id === product.id && item.selectedSize === size && item.selectedColor === color)
            ? { ...item, quantity: item.quantity + quantity } 
            : item
        );
      }
      return [...prev, { ...product, quantity, selectedSize: size, selectedColor: color } as CartItem];
    });
  };

  const updateQuantity = (id: string, quantity: number) => {
    setCartItems(prev => prev.map(item => item.id === id ? { ...item, quantity } : item));
  };

  const removeFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const handleCheckoutComplete = (method: string) => {
    if (!currentUser) {
      setView('auth');
      return;
    }

    const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const shipping = subtotal > 99 ? 0 : 15;
    const orderTotal = subtotal + shipping;
    
    const newOrder = orderService.createOrder(cartItems, orderTotal);
    const newTransaction = orderService.createTransaction(newOrder.id, orderTotal, method);

    setOrders([newOrder, ...orders]);
    setTransactions([newTransaction, ...transactions]);
    alert('Order placed successfully! Thank you for shopping with E.buy.');
    setCartItems([]);
    setView('home');
  };

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    setView('home');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setOrders([]);
    setTransactions([]);
    setView('home');
  };

  const cartTotalCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen bg-brand-light flex flex-col">
      <Navbar 
        cartCount={cartTotalCount} 
        onCartClick={() => setView('cart')}
        onLogoClick={handleLogoClick}
        onCategoryClick={handleCategoryClick}
        onUserClick={() => currentUser ? setView('profile') : setView('auth')}
      />
      
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          {view === 'home' && (
            <HomePage onProductClick={handleProductClick} onCategoryClick={handleCategoryClick} />
          )}
          
          {view === 'product' && selectedProduct && (
            <ProductPage 
              key="product"
              product={selectedProduct} 
              onBack={() => setView('home')} 
              onAddToCart={handleAddToCart}
            />
          )}

          {view === 'cart' && (
            <CartPage 
              key="cart"
              items={cartItems}
              onBack={() => setView('home')}
              onUpdateQuantity={updateQuantity}
              onRemove={removeFromCart}
              onCheckout={() => {
                if (currentUser) {
                  setView('checkout');
                } else {
                  alert('Please sign in to proceed with checkout.');
                  setView('auth');
                }
              }}
            />
          )}

          {view === 'categories' && (
            <CategoriesPage 
              key="categories"
              initialCategory={activeCategory}
              onBack={() => setView('home')}
              onProductClick={handleProductClick}
            />
          )}

          {view === 'auth' && (
            <AuthPage 
              key="auth"
              onAuthSuccess={handleAuthSuccess}
              onBack={() => setView('home')}
            />
          )}

          {view === 'profile' && currentUser && (
            <ProfilePage 
              key="profile"
              user={currentUser}
              orders={orders}
              transactions={transactions}
              onLogout={handleLogout}
              onUpdateUser={setCurrentUser}
            />
          )}

          {view === 'checkout' && (
            <CheckoutPage 
              key="checkout"
              items={cartItems}
              onBack={() => setView('cart')}
              onComplete={handleCheckoutComplete}
            />
          )}
        </AnimatePresence>
      </main>
      
      <BottomNavbar 
        currentView={view}
        cartCount={cartTotalCount}
        onHomeClick={handleLogoClick}
        onDiscoverClick={() => handleCategoryClick('All')}
        onCartClick={() => setView('cart')}
        onUserClick={() => currentUser ? setView('profile') : setView('auth')}
      />

      <Footer />
      {/* Spacer for mobile bottom navbar */}
      <div className="h-28 md:hidden"></div>
    </div>
  );
}
