import { User } from '../types';

export const login = async (email: string, password: string): Promise<User> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: 'u-1',
        name: 'John Doe',
        email: email,
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=100&auto=format&fit=crop',
        joinedAt: 'Jan 2024'
      });
    }, 1000);
  });
};

export const register = async (name: string, email: string, password: string): Promise<User> => {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        id: 'u-' + Math.random().toString(36).substr(2, 9),
        name: name,
        email: email,
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=100&auto=format&fit=crop',
        joinedAt: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
      });
    }, 1000);
  });
};
