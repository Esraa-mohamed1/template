import { Product } from '../types';

export const products: Product[] = [
  {
    id: 'p1',
    name: "Classic Trench Coat",
    price: 299.99,
    oldPrice: 399.99,
    discount: 25,
    rating: 4.8,
    category: "Women",
    img: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=800&auto=format&fit=crop",
    description: "A timeless silhouette for the modern woman. Waterproof and elegant.",
    gallery: [
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?q=80&w=800&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1544022613-e87ce7526ed1?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: 'p2',
    name: "Urban Tech Parka",
    price: 450.00,
    rating: 4.9,
    category: "Men",
    img: "https://images.unsplash.com/photo-1544022613-e87ce7526ed1?q=80&w=800&auto=format&fit=crop",
    description: "Built for city winters. Heat-mapping technology and premium insulation.",
    gallery: [
      "https://images.unsplash.com/photo-1544022613-e87ce7526ed1?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: 'p3',
    name: "Merino Wool Sweater",
    price: 120.00,
    oldPrice: 150.00,
    discount: 20,
    rating: 4.7,
    category: "Men",
    img: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=800&auto=format&fit=crop",
    description: "Breathable, soft, and ethically sourced Merino wool from New Zealand.",
    gallery: [
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: 'p4',
    name: "Silk Evening Gown",
    price: 599.00,
    rating: 5.0,
    category: "Women",
    img: "https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=800&auto=format&fit=crop",
    description: "Exquisite Italian silk tailored for a perfect evening silhouette.",
    gallery: [
      "https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: 'p5',
    name: "Junior Explorer Set",
    price: 85.00,
    rating: 4.6,
    category: "Children",
    img: "https://images.unsplash.com/photo-1519457431-7573954619b7?q=80&w=800&auto=format&fit=crop",
    description: "Durable and flexible. Best for active children.",
    gallery: [
      "https://images.unsplash.com/photo-1519457431-7573954619b7?q=80&w=800&auto=format&fit=crop"
    ]
  },
  {
    id: 'p6',
    name: "Luxe Cashmere Scarf",
    price: 75.00,
    rating: 4.9,
    category: "Accessories",
    img: "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?q=80&w=800&auto=format&fit=crop",
    description: "Ultra-soft cashmere warmth for cold mornings.",
    gallery: [
      "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?q=80&w=800&auto=format&fit=crop"
    ]
  }
];

export const getProducts = () => products;
export const getProductById = (id: string) => products.find(p => p.id === id);
export const getFilteredProducts = (category: string, priceRange: number[]) => {
  return products.filter(p => {
    const matchesCategory = category === 'All' || p.category === category || (category === 'Winter' && p.discount);
    const matchesPrice = p.price >= priceRange[0] && p.price <= priceRange[1];
    return matchesCategory && matchesPrice;
  });
};
